import * as React from "react";
import { PropertyControls, ControlType, Stack, Override } from "framer";

// Define type of property
interface Props {
    options: string;
}

export class radio extends React.Component<Props> {

    // Set default properties
    static defaultProps = {
    options: "Option 1,Option 2,Option 3",
    onChange: function,
    }

    // Items shown in property panel
    static propertyControls: PropertyControls = {
    options: { type: ControlType.String, title: "Options" },
    }

    state = {
        activeId: 0,
        activeName: this.props.options.split(",")[0]
        }

    toggleActive = (index, name) => {
        this.setState({
            activeId: index,
            activeName: name,
        })
        this.props.onChange({index, name})
    }

    componentDidMount() {
        this.props.onChange({index: this.state.activeId, name: this.state.activeName})
    }

    renderChildren(name, index) {
        return React.Children.map(this.props.children, child => {

            let [body, fill, label] = child.props.children
            
            label = React.cloneElement(label, {
                rawHTML: label.props.rawHTML.replace(/Label/g, name)
            
            })
            body = React.cloneElement(body, {})
            fill = React.cloneElement(fill, {
                left: body.props.width / 2 - fill.props.width / 2,
                scale: (this.state.activeId == index) ? 1 : 0,
                style: {transition: "all .2s ease"}
            })

            return [body, fill, label]
        })
      }

    render() {
        const { width, height, children, options } = this.props
        const optionsArray = options.split(",")
        const content = children[0] ?
            <Stack width = {width} height = {height} style = {{backgroundColor: null}}>
            {
                optionsArray.map((name, index) => {
                    return (
                        <div
                        onClick = {() => this.toggleActive(index, name)}
                        style = {{
                            display: "flex",
                            alignItems: "center",
                            height: children[0].props.height,

                        }}
                        key = {index}
                        >
                            {this.renderChildren(name, index)}
                        </div>
                    )
                })
            }
            </Stack> :
            <div
                width = {width}
                height = {height}
                style = {{
                    padding: 24,
                    display: "flex",
                    alignItems: "center",
                    textAlign: "center",
                    backgroundColor: "rgba(136, 85, 255, 0.1)",
                    height: height,
                    color: "#8855FF",
                }}
            >
                Connect children layer to see the result
            </div>
        
        return (
            content
        )
    }
}