import { Data, animate, Override, Animatable } from "framer"
import {findDOMNode} from "react-dom"

const data = Data({
    selectedItems:[],
    textHeight: 0
})

let text = ""
let topOffset = 156
let offset = topOffset

// const getLabel = node => {
//     let text = findDOMNode(node)
//     // console.log(text)
//     data.text = text.children[0].children[0].children[0]
// }

export const HandleChange_: Override = () => {
    return {
        onChange(selectedItems) {
            data.selectedItems = [...selectedItems],
            text = data.selectedItems.reduce((all, current) => all + current.name + ', ' , "")
            topOffset = text == "" ? 156 : 204
            offset = topOffset - data.selectedItems.length * 48
        },
    }
}

export const UpdateLabel_: Override = (height) => {
    let getLabel = node => {
        let label = findDOMNode(node)
        if (label !== null){
            console.log(label.children[0].getClientBoundRect())
        }
            
    }
    return {
        text: text,
        top: offset,
        ref: getLabel
    }
}