import * as React from "react";
import { PropertyControls, ControlType, Stack, Override } from "framer";

// Define type of property
interface Props {
    options: string;
}

export class check extends React.Component<Props> {

    // Set default properties
    static defaultProps = {
    options: "Option 1,Option 2,Option 3",
    onChange: function,
    }

    // Items shown in property panel
    static propertyControls: PropertyControls = {
    options: { type: ControlType.String, title: "Options" },
    }

    state = {
        selectedItems: []
        }

    toggleActive = (index, name) => {
        const items = this.state.selectedItems
        let isAlreadySelected = false
        let result = []

        //Check if item already exists
        items.map((item) => {
            if (item.index == index) {
                isAlreadySelected = true
            }
        })

        if (isAlreadySelected) {
            result = [...items.filter((item) => item.index !== index)]
        } else {
            result = [...items, {index: index, name: name}]
        }

        this.setState({
            selectedItems: result
        })
        
        this.props.onChange(result)
    }

    // componentDidMount() {
    //     // console.log("mount")
    //     this.props.onChange(this.state.activeId, this.state.activeName)
    // }

    renderChildren = (index, name) => {
        return React.Children.map(this.props.children, child => {

            let [body, fill, label] = child.props.children
            let scale = 0
            
            this.state.selectedItems.map((item) => {
                if (item.index == index) {
                    scale = 1
                }
            })
            
            label = React.cloneElement(label, {
                rawHTML: label.props.rawHTML.replace(/Label/g, name)
            
            })
            body = React.cloneElement(body, {})
            fill = React.cloneElement(fill, {
                left: body.props.width / 2 - fill.props.width / 2,
                scale: scale,
                style: {transition: "all .2s ease"}
            })

            return [body, fill, label]
        })
      }

    render() {
        const { width, height, children, options } = this.props
        const optionsArray = options.split(",")
        const content = children[0] ?
            <Stack width = {width} height = {height}>
            {
                optionsArray.map((name, index) => {
                    return (
                        <div
                        onClick = {() => this.toggleActive(index, name)}
                        style = {{
                            display: "flex",
                            alignItems: "center",
                            height: children[0].props.height,

                        }}
                        key = {index}
                        >
                            {this.renderChildren(index, name)}
                        </div>
                    )
                })
            }
            </Stack> :
            <div
                width = {width}
                height = {height}
                style = {{
                    padding: 24,
                    display: "flex",
                    alignItems: "center",
                    textAlign: "center",
                    backgroundColor: "rgba(136, 85, 255, 0.1)",
                    height: height,
                    color: "#8855FF",
                }}
            >
                Connect children layer to see the result
            </div>
        
        return (
            content
        )
    }
}