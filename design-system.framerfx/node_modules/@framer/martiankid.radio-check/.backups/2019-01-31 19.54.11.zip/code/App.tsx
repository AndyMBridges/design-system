import { Data, animate, Override, Animatable } from "framer"

const data = Data({id: 0, name: ""})

export const HandleChange: Override = () => {
    return {
        onChange(obj) {
            data.id = obj.index
            data.name = obj.name
     
        },
    }
}

export const UpdateLabel: Override = () => {
    return {
        text: data.name
    }
}
