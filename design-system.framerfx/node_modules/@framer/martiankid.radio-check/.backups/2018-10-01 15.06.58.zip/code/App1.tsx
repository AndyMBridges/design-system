import { Data, animate, Override, Animatable } from "framer"
import {findDOMNode} from "react-dom"

const data = Data({
    selectedItems:[],
})

let text = ""
let topOffset = 204
let offset = topOffset
let textHeight = 48

export const HandleChange_: Override = () => {
    return {
        onChange(selectedItems) {
            data.selectedItems = [...selectedItems],
            text = data.selectedItems.reduce((all, current) => all + current.name + ', ' , "")
            offset = topOffset - textHeight
        },
    }
}

export const UpdateLabel_: Override = (height) => {
    let getLabel = node => {
        let label = findDOMNode(node)
        if (label !== null) {
            textHeight = label.children[0].getBoundingClientRect().height
            console.log(textHeight)
        }  
    }
    return {
        text: text,
        top: offset,
        ref: getLabel
    }
}