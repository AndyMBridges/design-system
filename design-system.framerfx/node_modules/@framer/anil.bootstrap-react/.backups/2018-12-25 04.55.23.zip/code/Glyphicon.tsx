import * as React from "react";
import { Glyphicon as _Glyphicon, Button } from "../lib";
import { PropertyControls, ControlType } from "framer";

// Define type of property
interface Props {
  text: string;
}

export class Glyphicon extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: "Hello World!"
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: "Text" }
  };

  render() {
    return (
      <Button>
        <_Glyphicon glyph="align-left" />
      </Button>
    );
  }
}
