// WARNING: this file is auto generated, any changes will be lost
import { createDesignComponent, CanvasStore } from "framer"
const canvas = CanvasStore.shared(); // CANVAS_DATA;
export const AppViewAccordianCollapsed = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string}>(canvas, "id_ZsVU3Bn62", {}, 611,60);
export const Modal_Component = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string}>(canvas, "id_nx9uWXNUn", {}, 1440,828);
export const NBSCaseStatus = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string}>(canvas, "id_U6QC6BXiW", {}, 323,42);
export const NBSHeader = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string}>(canvas, "id_cp72gzaN4", {}, 1440,72);
export const NBSTabs = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string}>(canvas, "id_wl1Wd20go", {}, 1280,62);
export const NBS_EV_Root_View = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string}>(canvas, "id_YxNsetNaf", {}, 1440,1733);
export const Radio_Group = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string}>(canvas, "id_inDVUBome", {}, 569,135);
